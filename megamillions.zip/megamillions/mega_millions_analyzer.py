import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
import json
import os
from collections import Counter, defaultdict
import time

class MegaMillionsAnalyzer:
    def __init__(self):
        self.data_file = "megamillions_data.json"
        self.numbers_range = list(range(1, 71))  # Regular numbers 1-70
        self.mega_ball_range = list(range(1, 26))  # Mega Ball 1-25
        self.draw_frequency = "Twice a week (Tuesday and Friday)"  # Mega Millions draws twice a week
        self.data = None
        self.log_file = "mega_millions_analysis.txt"
        self.initialize_log()
        
    def initialize_log(self):
        """Initialize the log file with a header"""
        with open(self.log_file, 'w') as f:
            f.write(f"Mega Millions Analysis Log\n")
            f.write(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("=" * 50 + "\n\n")

    def log_analysis(self, message: str):
        """Add a message to the analysis log"""
        with open(self.log_file, 'a') as f:
            f.write(f"{message}\n")

    def fetch_data(self):
        """Load data from the JSON file"""
        print("Loading Mega Millions data from file...")
        
        try:
            with open(self.data_file, 'r') as f:
                data = json.load(f)
            return data
        except FileNotFoundError:
            print("Data file not found. Please run extract_pdf_data.py first.")
            return None
        except json.JSONDecodeError:
            print("Error reading data file. Please run extract_pdf_data.py first.")
            return None
    
    def process_data(self, data):
        """Process the raw data into a pandas DataFrame"""
        if not data or 'data' not in data:
            print("No data available")
            return None
        
        # Extract the rows from the data
        rows = data['data']
        
        # Create a list to store the processed data
        processed_data = []
        
        for row in rows:
            # The data is in a specific format
            draw_date = row[0]  # Draw date
            winning_numbers = row[1]  # Winning numbers
            mega_ball = row[2]  # Mega Ball
            
            # Parse the winning numbers
            numbers = [int(n) for n in winning_numbers.split()]
            
            # Add to processed data
            processed_data.append({
                'draw_date': draw_date,
                'numbers': numbers,
                'mega_ball': int(mega_ball)
            })
        
        # Convert to DataFrame
        df = pd.DataFrame(processed_data)
        
        # Convert draw_date to datetime
        df['draw_date'] = pd.to_datetime(df['draw_date'])
        
        # Sort by draw date (newest first)
        df = df.sort_values('draw_date', ascending=False)
        
        return df
    
    def analyze_frequency(self, df):
        """Analyze the frequency of each number and their time frames"""
        # Count regular numbers with time frames
        regular_number_occurrences = defaultdict(list)
        for idx, row in df.iterrows():
            draw_date = row['draw_date']
            numbers = row['numbers']
            for num in numbers:
                regular_number_occurrences[num].append(draw_date)
        
        # Count Mega Ball with time frames
        mega_ball_occurrences = defaultdict(list)
        for idx, row in df.iterrows():
            draw_date = row['draw_date']
            mega_ball = row['mega_ball']
            mega_ball_occurrences[mega_ball].append(draw_date)
        
        return regular_number_occurrences, mega_ball_occurrences
    
    def analyze_time_between_occurrences(self, df):
        """Analyze the time between occurrences of the same number"""
        # Create a dictionary to store the last occurrence of each number
        last_occurrence = {}
        time_between = defaultdict(list)
        
        # Sort by draw date (oldest first)
        df_sorted = df.sort_values('draw_date', ascending=True)
        
        # Analyze regular numbers
        for idx, row in df_sorted.iterrows():
            draw_date = row['draw_date']
            
            for number in row['numbers']:
                if number in last_occurrence:
                    # Calculate time difference
                    time_diff = draw_date - last_occurrence[number]
                    time_between[number].append(time_diff)
                
                # Update last occurrence
                last_occurrence[number] = draw_date
        
        # Analyze Mega Ball
        mega_ball_last = {}
        mega_ball_time_between = defaultdict(list)
        
        for idx, row in df_sorted.iterrows():
            draw_date = row['draw_date']
            mega_ball = row['mega_ball']
            
            if mega_ball in mega_ball_last:
                # Calculate time difference
                time_diff = draw_date - mega_ball_last[mega_ball]
                mega_ball_time_between[mega_ball].append(time_diff)
            
            # Update last occurrence
            mega_ball_last[mega_ball] = draw_date
        
        return time_between, mega_ball_time_between
    
    def analyze_consecutive_occurrences(self, df):
        """Analyze the probability of a number appearing consecutively"""
        # Sort by draw date (oldest first)
        df_sorted = df.sort_values('draw_date', ascending=True)
        
        # Initialize counters
        consecutive_counts = {2: 0, 3: 0, 4: 0}
        total_draws = len(df_sorted)
        
        # Check for consecutive occurrences of regular numbers
        for i in range(total_draws - 1):
            current_numbers = set(df_sorted.iloc[i]['numbers'])
            next_numbers = set(df_sorted.iloc[i+1]['numbers'])
            
            # Check for 2 consecutive occurrences
            common = current_numbers.intersection(next_numbers)
            if len(common) >= 2:
                consecutive_counts[2] += 1
            
            # Check for 3 consecutive occurrences
            if i < total_draws - 2:
                next_next_numbers = set(df_sorted.iloc[i+2]['numbers'])
                common = current_numbers.intersection(next_numbers).intersection(next_next_numbers)
                if len(common) >= 3:
                    consecutive_counts[3] += 1
            
            # Check for 4 consecutive occurrences
            if i < total_draws - 3:
                next_next_next_numbers = set(df_sorted.iloc[i+3]['numbers'])
                common = current_numbers.intersection(next_numbers).intersection(next_next_numbers).intersection(next_next_next_numbers)
                if len(common) >= 4:
                    consecutive_counts[4] += 1
        
        # Calculate probabilities
        probabilities = {
            2: consecutive_counts[2] / (total_draws - 1) * 100,
            3: consecutive_counts[3] / (total_draws - 2) * 100,
            4: consecutive_counts[4] / (total_draws - 3) * 100
        }
        
        return probabilities
    
    def predict_next_numbers(self, df, regular_number_occurrences, mega_ball_occurrences):
        """Predict the next winning numbers based on frequency analysis"""
        # Get the most common numbers
        most_common_numbers = sorted(
            [(num, len(dates)) for num, dates in regular_number_occurrences.items()],
            key=lambda x: (-x[1], x[0])
        )[:10]
        most_common_numbers = [num for num, _ in most_common_numbers]
        
        # Get the most common Mega Ball
        most_common_mega = sorted(
            [(num, len(dates)) for num, dates in mega_ball_occurrences.items()],
            key=lambda x: (-x[1], x[0])
        )[:5]
        most_common_mega = [num for num, _ in most_common_mega]
        
        # Get the least common numbers (hot numbers)
        least_common_numbers = sorted(
            [(num, len(dates)) for num, dates in regular_number_occurrences.items()],
            key=lambda x: (x[1], x[0])
        )[:10]
        least_common_numbers = [num for num, _ in least_common_numbers]
        
        # Get the least common Mega Ball
        least_common_mega = sorted(
            [(num, len(dates)) for num, dates in mega_ball_occurrences.items()],
            key=lambda x: (x[1], x[0])
        )[:5]
        least_common_mega = [num for num, _ in least_common_mega]
        
        # Generate predictions
        predictions = {
            'based_on_frequency': {
                'regular_numbers': most_common_numbers[:5],
                'mega_ball': most_common_mega[0] if most_common_mega else None
            },
            'hot_numbers': {
                'regular_numbers': least_common_numbers[:5],
                'mega_ball': least_common_mega[0] if least_common_mega else None
            },
            'mixed_strategy': {
                'regular_numbers': most_common_numbers[:3] + least_common_numbers[:2],
                'mega_ball': most_common_mega[0] if most_common_mega else None
            }
        }
        
        return predictions
    
    def visualize_frequency(self, regular_number_occurrences, mega_ball_occurrences):
        """Visualize the frequency of each number"""
        # Create a figure with two subplots
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10))
        
        # Plot regular numbers frequency
        numbers = list(regular_number_occurrences.keys())
        frequencies = [len(dates) for dates in regular_number_occurrences.values()]
        
        ax1.bar(numbers, frequencies, color='blue', alpha=0.7)
        ax1.set_title('Frequency of Regular Numbers')
        ax1.set_xlabel('Number')
        ax1.set_ylabel('Frequency')
        ax1.grid(True, linestyle='--', alpha=0.7)
        
        # Plot Mega Ball frequency
        mega_numbers = list(mega_ball_occurrences.keys())
        mega_frequencies = [len(dates) for dates in mega_ball_occurrences.values()]
        
        ax2.bar(mega_numbers, mega_frequencies, color='gold', alpha=0.7)
        ax2.set_title('Frequency of Mega Ball Numbers')
        ax2.set_xlabel('Number')
        ax2.set_ylabel('Frequency')
        ax2.grid(True, linestyle='--', alpha=0.7)
        
        plt.tight_layout()
        plt.savefig('megamillions_frequency.png')
        plt.close()
    
    def visualize_time_between(self, time_between, mega_ball_time_between):
        """Visualize the time between occurrences of the same number"""
        # Create a figure with two subplots
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10))
        
        # Plot regular numbers time between
        all_times = []
        for times in time_between.values():
            all_times.extend([t.days for t in times])
        
        ax1.hist(all_times, bins=20, color='blue', alpha=0.7)
        ax1.set_title('Time Between Occurrences of Regular Numbers')
        ax1.set_xlabel('Days')
        ax1.set_ylabel('Frequency')
        ax1.grid(True, linestyle='--', alpha=0.7)
        
        # Plot Mega Ball time between
        all_mega_times = []
        for times in mega_ball_time_between.values():
            all_mega_times.extend([t.days for t in times])
        
        ax2.hist(all_mega_times, bins=20, color='gold', alpha=0.7)
        ax2.set_title('Time Between Occurrences of Mega Ball Numbers')
        ax2.set_xlabel('Days')
        ax2.set_ylabel('Frequency')
        ax2.grid(True, linestyle='--', alpha=0.7)
        
        plt.tight_layout()
        plt.savefig('megamillions_time_between.png')
        plt.close()
    
    def format_time_frame(self, dates):
        """Format the time frame of occurrences"""
        if not dates:
            return "No occurrences"
        if len(dates) == 1:
            return f"Only on {dates[0].strftime('%Y-%m-%d')}"
        
        # Sort dates in ascending order
        dates = sorted(dates)
        first_date = dates[0].strftime('%Y-%m-%d')
        last_date = dates[-1].strftime('%Y-%m-%d')
        
        if first_date == last_date:
            return f"Only on {first_date}"
        return f"From {first_date} to {last_date}"
    
    def run_analysis(self):
        """Run the complete analysis"""
        if self.data is None:
            self.data = self.fetch_data()

        self.log_analysis("Starting Mega Millions Analysis")
        self.log_analysis(f"Analyzing {len(self.data)} draws\n")

        # Process data
        df = self.process_data(self.data)
        if df is None or df.empty:
            print("No data to analyze")
            return
        
        self.log_analysis(f"Analyzing {len(df)} Mega Millions draws")
        
        # Analyze frequency with time frames
        regular_number_occurrences, mega_ball_occurrences = self.analyze_frequency(df)
        
        # Sort numbers by frequency
        sorted_regular_numbers = sorted(
            [(num, len(dates)) for num, dates in regular_number_occurrences.items()],
            key=lambda x: (-x[1], x[0])
        )
        
        sorted_mega_balls = sorted(
            [(num, len(dates)) for num, dates in mega_ball_occurrences.items()],
            key=lambda x: (-x[1], x[0])
        )

        self.log_analysis("\n----- All Regular Number Occurrences with Time Frames -----")
        for num, count in sorted_regular_numbers:
            time_frame = self.format_time_frame(regular_number_occurrences[num])
            percentage = (count / len(df)) * 100
            self.log_analysis(f"Number {num}: {count} times ({percentage:.2f}%) - {time_frame}")

        self.log_analysis("\n----- All Mega Ball Occurrences with Time Frames -----")
        for num, count in sorted_mega_balls:
            time_frame = self.format_time_frame(mega_ball_occurrences[num])
            percentage = (count / len(df)) * 100
            self.log_analysis(f"Number {num}: {count} times ({percentage:.2f}%) - {time_frame}")
        
        self.log_analysis("\n===== MEGA MILLIONS ANALYSIS RESULTS =====")
        self.log_analysis(f"Draw Frequency: {self.draw_frequency}")
        self.log_analysis(f"Total Draws Analyzed: {len(df)}")
        
        self.log_analysis("\n----- Most Common Regular Numbers -----")
        for num, count in sorted_regular_numbers[:10]:
            percentage = (count / len(df)) * 100
            self.log_analysis(f"Number {num}: {count} times ({percentage:.2f}%)")
        
        self.log_analysis("\n----- Most Common Mega Ball Numbers -----")
        for num, count in sorted_mega_balls[:5]:
            percentage = (count / len(df)) * 100
            self.log_analysis(f"Number {num}: {count} times ({percentage:.2f}%)")
        
        self.log_analysis("\n----- Least Common Regular Numbers (Hot Numbers) -----")
        for num, count in sorted(sorted_regular_numbers[-10:], key=lambda x: (x[1], x[0])):
            percentage = (count / len(df)) * 100
            self.log_analysis(f"Number {num}: {count} times ({percentage:.2f}%)")
        
        self.log_analysis("\n----- Least Common Mega Ball Numbers (Hot Numbers) -----")
        for num, count in sorted(sorted_mega_balls[-5:], key=lambda x: (x[1], x[0])):
            percentage = (count / len(df)) * 100
            self.log_analysis(f"Number {num}: {count} times ({percentage:.2f}%)")
        
        # Analyze time between occurrences
        time_between, mega_ball_time_between = self.analyze_time_between_occurrences(df)
        
        # Analyze consecutive occurrences
        consecutive_probabilities = self.analyze_consecutive_occurrences(df)
        
        # Predict next numbers
        predictions = self.predict_next_numbers(df, regular_number_occurrences, mega_ball_occurrences)
        
        # Visualize results
        self.visualize_frequency(regular_number_occurrences, mega_ball_occurrences)
        self.visualize_time_between(time_between, mega_ball_time_between)
        
        # Print results
        self.log_analysis("\n===== MEGA MILLIONS ANALYSIS RESULTS =====")
        self.log_analysis(f"Draw Frequency: {self.draw_frequency}")
        self.log_analysis(f"Total Draws Analyzed: {len(df)}")
        
        # Count frequency of regular numbers
        regular_number_counts = {}
        for draw in df.values:
            numbers = draw[1]
            for num in numbers:
                regular_number_counts[num] = regular_number_counts.get(num, 0) + 1

        # Count frequency of Mega Ball numbers
        mega_ball_counts = {}
        for draw in df.values:
            mega_ball = draw[2]
            mega_ball_counts[mega_ball] = mega_ball_counts.get(mega_ball, 0) + 1

        # Sort all numbers by frequency (not just most common)
        sorted_regular_numbers = sorted(regular_number_counts.items(), key=lambda x: (-x[1], x[0]))
        sorted_mega_balls = sorted(mega_ball_counts.items(), key=lambda x: (-x[1], x[0]))

        self.log_analysis("\n----- All Regular Number Occurrences -----")
        for num, count in sorted_regular_numbers:
            percentage = (count / len(df)) * 100
            self.log_analysis(f"Number {num}: {count} times ({percentage:.2f}%)")

        self.log_analysis("\n----- All Mega Ball Occurrences -----")
        for num, count in sorted_mega_balls:
            percentage = (count / len(df)) * 100
            self.log_analysis(f"Number {num}: {count} times ({percentage:.2f}%)")
        
        self.log_analysis("\n----- Respective Time Between Occurrences -----")
        # Sort by draw date (newest first)
        df_sorted = df.sort_values('draw_date', ascending=False)
        
        # Get the most recent draw date
        most_recent_date = df_sorted.iloc[0]['draw_date']
        
        # Create a dictionary to store the last occurrence of each number
        last_occurrence = {}
        
        # Analyze regular numbers
        for idx, row in df_sorted.iterrows():
            draw_date = row['draw_date']
            
            for number in row['numbers']:
                if number not in last_occurrence:
                    last_occurrence[number] = draw_date
        
        # Calculate time since last occurrence for each number
        time_since_last = {}
        for number, last_date in last_occurrence.items():
            time_since_last[number] = most_recent_date - last_date
        
        # Print the time since last occurrence for each number
        for number, time_diff in sorted(time_since_last.items(), key=lambda x: x[1].days):
            self.log_analysis(f"Number {number}: {time_diff.days} days since last occurrence")
        
        # Analyze Mega Ball
        mega_ball_last = {}
        
        for idx, row in df_sorted.iterrows():
            draw_date = row['draw_date']
            mega_ball = row['mega_ball']
            
            if mega_ball not in mega_ball_last:
                mega_ball_last[mega_ball] = draw_date
        
        # Calculate time since last occurrence for each Mega Ball
        mega_ball_time_since_last = {}
        for mega_ball, last_date in mega_ball_last.items():
            mega_ball_time_since_last[mega_ball] = most_recent_date - last_date
        
        # Print the time since last occurrence for each Mega Ball
        self.log_analysis("\n----- Respective Time Between Mega Ball Occurrences -----")
        for mega_ball, time_diff in sorted(mega_ball_time_since_last.items(), key=lambda x: x[1].days):
            self.log_analysis(f"Mega Ball {mega_ball}: {time_diff.days} days since last occurrence")
        
        self.log_analysis("\n----- Consecutive Occurrence Probabilities -----")
        self.log_analysis(f"Same number appearing twice in a row: {consecutive_probabilities[2]:.2f}%")
        self.log_analysis(f"Same number appearing three times in a row: {consecutive_probabilities[3]:.2f}%")
        self.log_analysis(f"Same number appearing four times in a row: {consecutive_probabilities[4]:.2f}%")
        
        self.log_analysis("\n----- Predicted Numbers for Next Draw -----")
        self.log_analysis("Based on frequency:")
        self.log_analysis(f"Regular Numbers: {predictions['based_on_frequency']['regular_numbers']}")
        self.log_analysis(f"Mega Ball: {predictions['based_on_frequency']['mega_ball']}")
        
        self.log_analysis("\nHot numbers strategy:")
        self.log_analysis(f"Regular Numbers: {predictions['hot_numbers']['regular_numbers']}")
        self.log_analysis(f"Mega Ball: {predictions['hot_numbers']['mega_ball']}")
        
        self.log_analysis("\nMixed strategy:")
        self.log_analysis(f"Regular Numbers: {predictions['mixed_strategy']['regular_numbers']}")
        self.log_analysis(f"Mega Ball: {predictions['mixed_strategy']['mega_ball']}")
        
        self.log_analysis("\nVisualizations have been saved as 'megamillions_frequency.png' and 'megamillions_time_between.png'")
        self.log_analysis("Analysis complete. Visualizations have been saved.")
        print(f"Analysis complete. Results have been saved to {self.log_file}")

if __name__ == "__main__":
    analyzer = MegaMillionsAnalyzer()
    analyzer.run_analysis() 