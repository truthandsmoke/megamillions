import requests
import json
import os
from datetime import datetime
import pandas as pd
from typing import Dict, List, Optional

class LotteryTracker:
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key
        self.base_url = "https://api.lottery.com/v1"  # Replace with actual API endpoint
        self.budget_file = "lottery_budget.json"
        self.log_file = "lottery_log.txt"
        self.initialize_files()

    def initialize_files(self):
        """Initialize budget and log files if they don't exist"""
        if not os.path.exists(self.budget_file):
            self.save_budget({
                "total_spent": 0,
                "total_won": 0,
                "tickets": [],
                "draws_played": []
            })
        
        if not os.path.exists(self.log_file):
            with open(self.log_file, 'w') as f:
                f.write(f"Lottery Tracking Log - Started {datetime.now()}\n")

    def fetch_latest_draws(self, num_draws: int = 10) -> List[Dict]:
        """Fetch latest draws from the lottery API"""
        try:
            headers = {"Authorization": f"Bearer {self.api_key}"} if self.api_key else {}
            response = requests.get(
                f"{self.base_url}/mega-millions/draws",
                headers=headers,
                params={"limit": num_draws}
            )
            response.raise_for_status()
            return response.json()["draws"]
        except requests.RequestException as e:
            self.log_error(f"Error fetching draws: {str(e)}")
            return []

    def add_ticket(self, numbers: List[int], mega_ball: int, cost: float = 2.0):
        """Record a new ticket purchase"""
        budget = self.load_budget()
        ticket = {
            "date": datetime.now().isoformat(),
            "numbers": numbers,
            "mega_ball": mega_ball,
            "cost": cost
        }
        budget["tickets"].append(ticket)
        budget["total_spent"] += cost
        self.save_budget(budget)
        self.log_action(f"Added new ticket: {numbers} + {mega_ball}")

    def check_ticket(self, ticket_index: int) -> Dict:
        """Check if a ticket has won"""
        budget = self.load_budget()
        if ticket_index >= len(budget["tickets"]):
            return {"error": "Invalid ticket index"}

        ticket = budget["tickets"][ticket_index]
        latest_draws = self.fetch_latest_draws(1)
        if not latest_draws:
            return {"error": "Could not fetch latest draw"}

        latest_draw = latest_draws[0]
        matches = self.calculate_matches(ticket, latest_draw)
        winnings = self.calculate_winnings(matches)

        if winnings > 0:
            budget["total_won"] += winnings
            self.save_budget(budget)
            self.log_action(f"Ticket {ticket_index} won ${winnings}")

        return {
            "matches": matches,
            "winnings": winnings,
            "roi": (winnings - ticket["cost"]) / ticket["cost"] if ticket["cost"] > 0 else 0
        }

    def calculate_matches(self, ticket: Dict, draw: Dict) -> Dict:
        """Calculate number matches between ticket and draw"""
        regular_matches = len(set(ticket["numbers"]) & set(draw["numbers"]))
        mega_ball_match = ticket["mega_ball"] == draw["mega_ball"]
        return {
            "regular_matches": regular_matches,
            "mega_ball_match": mega_ball_match
        }

    def calculate_winnings(self, matches: Dict) -> float:
        """Calculate winnings based on matches"""
        # Simplified prize structure - update with actual Mega Millions prizes
        prize_table = {
            (5, True): 1000000,  # 5 regular + Mega Ball
            (5, False): 10000,   # 5 regular
            (4, True): 500,      # 4 regular + Mega Ball
            (4, False): 200,     # 4 regular
            (3, True): 50,       # 3 regular + Mega Ball
            (3, False): 10,      # 3 regular
            (2, True): 10,       # 2 regular + Mega Ball
            (1, True): 4,        # 1 regular + Mega Ball
            (0, True): 2,        # Mega Ball only
        }
        return prize_table.get((matches["regular_matches"], matches["mega_ball_match"]), 0)

    def get_budget_summary(self) -> Dict:
        """Get summary of budget and ROI"""
        budget = self.load_budget()
        total_tickets = len(budget["tickets"])
        total_cost = budget["total_spent"]
        total_won = budget["total_won"]
        roi = (total_won - total_cost) / total_cost if total_cost > 0 else 0

        return {
            "total_tickets": total_tickets,
            "total_spent": total_cost,
            "total_won": total_won,
            "net_profit": total_won - total_cost,
            "roi": roi,
            "roi_percentage": f"{roi * 100:.2f}%"
        }

    def export_log(self, filename: Optional[str] = None):
        """Export the log file to a text file"""
        if filename is None:
            filename = f"lottery_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        
        if os.path.exists(self.log_file):
            with open(self.log_file, 'r') as source, open(filename, 'w') as dest:
                dest.write(source.read())
            self.log_action(f"Log exported to {filename}")
            return True
        return False

    def load_budget(self) -> Dict:
        """Load budget data from file"""
        try:
            with open(self.budget_file, 'r') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {
                "total_spent": 0,
                "total_won": 0,
                "tickets": [],
                "draws_played": []
            }

    def save_budget(self, budget: Dict):
        """Save budget data to file"""
        with open(self.budget_file, 'w') as f:
            json.dump(budget, f, indent=2)

    def log_action(self, message: str):
        """Log an action to the log file"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(self.log_file, 'a') as f:
            f.write(f"[{timestamp}] {message}\n")

    def log_error(self, message: str):
        """Log an error to the log file"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(self.log_file, 'a') as f:
            f.write(f"[{timestamp}] ERROR: {message}\n") 