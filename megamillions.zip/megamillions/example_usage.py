from lottery_tracker import LotteryTracker

def main():
    # Initialize the tracker (replace with your API key if you have one)
    tracker = LotteryTracker(api_key="your_api_key_here")

    # Add some example tickets
    tracker.add_ticket([3, 1, 7, 11, 15], 19)  # Frequency-based strategy
    tracker.add_ticket([65, 67, 68, 62, 66], 2)  # Hot numbers strategy
    tracker.add_ticket([3, 1, 7, 65, 67], 19)  # Mixed strategy

    # Check the latest ticket
    result = tracker.check_ticket(-1)  # -1 refers to the most recent ticket
    if "error" not in result:
        print(f"Latest ticket results:")
        print(f"Matches: {result['matches']}")
        print(f"Winnings: ${result['winnings']}")
        print(f"ROI: {result['roi']*100:.2f}%")

    # Get budget summary
    summary = tracker.get_budget_summary()
    print("\nBudget Summary:")
    print(f"Total Tickets: {summary['total_tickets']}")
    print(f"Total Spent: ${summary['total_spent']}")
    print(f"Total Won: ${summary['total_won']}")
    print(f"Net Profit: ${summary['net_profit']}")
    print(f"Overall ROI: {summary['roi_percentage']}")

    # Export the log
    tracker.export_log("my_lottery_log.txt")
    print("\nLog has been exported to 'my_lottery_log.txt'")

if __name__ == "__main__":
    main() 