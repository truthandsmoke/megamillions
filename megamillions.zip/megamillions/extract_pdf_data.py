import PyPDF2
import re
import json
import os
from datetime import datetime

def extract_mega_millions_data(pdf_path):
    """Extract Mega Millions data from a PDF file"""
    data = {"data": []}
    
    # Open the PDF file
    with open(pdf_path, 'rb') as file:
        # Create a PDF reader object
        pdf_reader = PyPDF2.PdfReader(file)
        
        # Get the number of pages
        num_pages = len(pdf_reader.pages)
        
        # Extract text from each page
        for page_num in range(num_pages):
            # Get the page
            page = pdf_reader.pages[page_num]
            
            # Extract text from the page
            text = page.extract_text()
            
            # Split text into lines
            lines = text.split('\n')
            
            # Process each line
            current_numbers = []
            current_mega_ball = None
            current_date = None
            
            for line in lines:
                line = line.strip()
                
                # Try to parse as a number
                try:
                    num = int(line)
                    if len(current_numbers) < 5 and 1 <= num <= 70:
                        current_numbers.append(num)
                    elif len(current_numbers) == 5 and 1 <= num <= 25:
                        current_mega_ball = num
                    continue
                except ValueError:
                    pass
                
                # Try to parse as a date
                date_match = re.search(r'(\d{1,2}/\d{1,2}/\d{4})', line)
                if date_match and len(current_numbers) == 5 and current_mega_ball is not None:
                    date_str = date_match.group(1)
                    
                    try:
                        # Convert date to ISO format
                        date_obj = datetime.strptime(date_str, '%m/%d/%Y')
                        iso_date = date_obj.strftime('%Y-%m-%dT00:00:00')
                        
                        # Format numbers as a space-separated string
                        numbers_str = ' '.join(str(n) for n in current_numbers)
                        
                        # Add to data
                        data["data"].append([iso_date, numbers_str, str(current_mega_ball)])
                        
                        # Reset for next draw
                        current_numbers = []
                        current_mega_ball = None
                        current_date = None
                    except ValueError:
                        pass
    
    # Sort data by date (newest first)
    data["data"].sort(reverse=True)
    
    # Save data to JSON file
    with open('megamillions_data.json', 'w') as f:
        json.dump(data, f, indent=2)
    
    return data

if __name__ == "__main__":
    # Get the directory containing this script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    pdf_path = os.path.join(script_dir, "MegaMillions.pdf")
    data = extract_mega_millions_data(pdf_path)
    print(f"Extracted {len(data['data'])} Mega Millions draws from the PDF")
    
    # Print the first few draws to verify
    if data["data"]:
        print("\nMost recent draws:")
        for draw in data["data"][:5]:
            print(f"Date: {draw[0]}, Numbers: {draw[1]}, Mega Ball: {draw[2]}") 